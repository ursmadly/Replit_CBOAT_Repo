import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import useLocalStorage from "@/hooks/use-local-storage";
import AppLayout from "@/components/layout/AppLayout";
import {
  RefreshCw,
  Cpu,
  Server,
  FileText,
  ArrowLeft,
  Database,
  Shield,
  ClipboardList,
  Zap,
  BrainCircuit,
  Bot,
  Sparkles
} from "lucide-react";

// Type definition for the active tab
type AgentTab = "data-manager" | "central-monitor" | "csr";

export default function AiAgents() {
  const [activeTab, setActiveTab] = useState<AgentTab>("data-manager");
  const [showLegacyView, setShowLegacyView] = useLocalStorage("show-legacy-ai-view", false);
  const [_, navigate] = useLocation();

  // Handler for navigating to the original AI pages
  const handleNavigateToAiPage = (page: string) => {
    navigate(page);
  };

  // Create particle animation effect
  const [particles, setParticles] = useState<{x: number, y: number, size: number, speed: number, color: string}[]>([]);
  
  useEffect(() => {
    // Generate random particles for background effect
    const newParticles = Array.from({ length: 20 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 1,
      speed: Math.random() * 0.5 + 0.1,
      color: ['#3B82F6', '#10B981', '#8B5CF6', '#EC4899'][Math.floor(Math.random() * 4)]
    }));
    
    setParticles(newParticles);
    
    // Animate particles
    const interval = setInterval(() => {
      setParticles(prev => 
        prev.map(p => ({
          ...p,
          y: (p.y + p.speed) % 100,
          x: p.x + (Math.random() - 0.5) * 0.2
        }))
      );
    }, 100);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <AppLayout title="AI Agents Hub">
      {/* Flashy header for AI Agents */}
      <div className="relative mb-6 -mt-4 -mx-4 p-8 overflow-hidden bg-gradient-to-r from-blue-700 via-indigo-600 to-purple-700 text-white rounded-b-lg shadow-xl">
        {/* Background particles */}
        {particles.map((particle, i) => (
          <div 
            key={i}
            className="absolute rounded-full opacity-30"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              backgroundColor: particle.color,
            }}
          />
        ))}
        
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center">
            <div className="p-3 bg-indigo-800 rounded-lg mr-4 relative border border-indigo-500">
              <Sparkles className="h-10 w-10 text-indigo-200" />
              <div className="absolute top-0 right-0 h-3 w-3 bg-cyan-400 rounded-full animate-ping"></div>
            </div>
            <div>
              <h1 className="text-4xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-teal-400">
                AI Agents Hub
              </h1>
              <p className="text-indigo-200 mt-1">Advanced intelligent agents to revolutionize clinical trial management</p>
            </div>
          </div>
          <Badge className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 text-sm">
            <Zap className="h-4 w-4 mr-1" />
            Next-Gen AI Platform
          </Badge>
        </div>
      </div>
      
      <div className="space-y-4">
        {showLegacyView ? (
          <>
            <Alert variant="default" className="bg-amber-50 border-amber-200">
              <Cpu className="h-4 w-4 text-amber-700" />
              <AlertTitle className="text-amber-800">Legacy AI Agent View</AlertTitle>
              <AlertDescription className="text-amber-700">
                You're viewing the legacy separate AI agents. To use the new consolidated view, click the button below.
              </AlertDescription>
              <Button 
                className="mt-2 bg-amber-600 hover:bg-amber-700" 
                onClick={() => setShowLegacyView(false)}
              >
                Switch to Consolidated View
              </Button>
            </Alert>

            {/* Legacy view navigation */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" 
                onClick={() => handleNavigateToAiPage("/data-manager-ai")}>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <Cpu className="h-5 w-5 text-teal-500 mr-2" />
                    Data Manager.AI
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">Advanced data orchestration and integration engine</p>
                  <Button className="mt-4 w-full" variant="outline">Launch</Button>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:shadow-md transition-shadow" 
                onClick={() => handleNavigateToAiPage("/central-monitor-ai")}>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <Server className="h-5 w-5 text-red-500 mr-2" />
                    Central Monitor.AI
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">Advanced trial monitoring and risk detection system</p>
                  <Button className="mt-4 w-full" variant="outline">Launch</Button>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:shadow-md transition-shadow" 
                onClick={() => handleNavigateToAiPage("/csr-ai")}>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 text-blue-500 mr-2" />
                    CSR.AI
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500">Intelligent clinical study reporting assistant</p>
                  <Button className="mt-4 w-full" variant="outline">Launch</Button>
                </CardContent>
              </Card>
            </div>
          </>
        ) : (
          <>
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-blue-800">AI Agents Hub</h2>
              <Button 
                variant="outline" 
                onClick={() => setShowLegacyView(true)}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Switch to Legacy View
              </Button>
            </div>

            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as AgentTab)} className="w-full">
              <TabsList className="flex justify-center gap-2 w-full mb-6 p-1 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <TabsTrigger 
                  value="data-manager" 
                  className="flex items-center gap-2 px-6 py-4 transition-all relative overflow-hidden"
                >
                  <div className={`absolute inset-0 ${activeTab === 'data-manager' ? 'bg-gradient-to-r from-pink-500/90 to-fuchsia-600/90' : 'bg-transparent'} transition-all duration-300 rounded-md`}></div>
                  <div className="relative z-10 flex items-center gap-2">
                    <div className={`p-1.5 ${activeTab === 'data-manager' ? 'bg-pink-600/30' : 'bg-gray-200 dark:bg-gray-700'} rounded-md transition-all duration-300`}>
                      <BrainCircuit className={`h-6 w-6 ${activeTab === 'data-manager' ? 'text-white' : 'text-pink-500 dark:text-pink-400'}`} />
                    </div>
                    <span className={`font-medium ${activeTab === 'data-manager' ? 'text-white' : ''}`}>Data Manager.AI</span>
                  </div>
                </TabsTrigger>
                
                <TabsTrigger 
                  value="central-monitor" 
                  className="flex items-center gap-2 px-6 py-4 transition-all relative overflow-hidden"
                >
                  <div className={`absolute inset-0 ${activeTab === 'central-monitor' ? 'bg-gradient-to-r from-purple-600/90 to-indigo-600/90' : 'bg-transparent'} transition-all duration-300 rounded-md`}></div>
                  <div className="relative z-10 flex items-center gap-2">
                    <div className={`p-1.5 ${activeTab === 'central-monitor' ? 'bg-purple-700/30' : 'bg-gray-200 dark:bg-gray-700'} rounded-md transition-all duration-300`}>
                      <Shield className={`h-5 w-5 ${activeTab === 'central-monitor' ? 'text-white' : 'text-purple-600 dark:text-purple-400'}`} />
                    </div>
                    <span className={`font-medium ${activeTab === 'central-monitor' ? 'text-white' : ''}`}>Central Monitor.AI</span>
                  </div>
                </TabsTrigger>
                
                <TabsTrigger 
                  value="csr" 
                  className="flex items-center gap-2 px-6 py-4 transition-all relative overflow-hidden"
                >
                  <div className={`absolute inset-0 ${activeTab === 'csr' ? 'bg-gradient-to-r from-blue-600/90 to-indigo-600/90' : 'bg-transparent'} transition-all duration-300 rounded-md`}></div>
                  <div className="relative z-10 flex items-center gap-2">
                    <div className={`p-1.5 ${activeTab === 'csr' ? 'bg-blue-700/30' : 'bg-gray-200 dark:bg-gray-700'} rounded-md transition-all duration-300`}>
                      <FileText className={`h-5 w-5 ${activeTab === 'csr' ? 'text-white' : 'text-blue-600 dark:text-blue-400'}`} />
                    </div>
                    <span className={`font-medium ${activeTab === 'csr' ? 'text-white' : ''}`}>CSR.AI</span>
                  </div>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="data-manager" className="p-0 m-0 border-none">
                <div className="space-y-6">
                  {/* Quantum Analyst Header with Hexagonal Frame */}
                  <div className="relative rounded-lg bg-gradient-to-r from-indigo-600 to-blue-700 p-6 shadow-lg">
                    {/* Grid pattern overlay */}
                    <div className="absolute inset-0 bg-grid-pattern opacity-5 rounded-lg"></div>
                    <div className="absolute inset-0 bg-black opacity-20 rounded-lg"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {/* Hexagonal frame with pulsing effect */}
                          <div className="relative">
                            <div className="absolute inset-0 bg-pink-400 opacity-20 animate-pulse rounded-xl"></div>
                            <div className="relative h-16 w-16 bg-gradient-to-br from-pink-500 to-fuchsia-600 rounded-xl flex items-center justify-center shadow-lg border border-pink-300">
                              <BrainCircuit className="h-9 w-9 text-white" />
                              {/* Animated particles */}
                              <div className="absolute top-1 right-1 h-1 w-1 bg-pink-200 rounded-full animate-ping"></div>
                              <div className="absolute bottom-2 left-1 h-1 w-1 bg-pink-200 rounded-full animate-ping" style={{ animationDelay: '0.5s' }}></div>
                              <div className="absolute top-2 left-2 h-1 w-1 bg-pink-200 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
                            </div>
                          </div>
                          <div className="ml-4">
                            <h2 className="text-2xl font-bold text-white flex items-center">
                              Quantum Analyst
                              <Badge className="ml-2 bg-pink-500 hover:bg-pink-600">Data Manager.AI</Badge>
                            </h2>
                            <p className="text-pink-100">Advanced data orchestration and integration engine</p>
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleNavigateToAiPage("/data-manager-ai")}
                          className="bg-pink-500 hover:bg-pink-600 text-white"
                        >
                          Launch Full Version
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Data Manager.AI Features</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <Database className="h-4 w-4 mr-2 text-pink-500" />
                            Data Quality Management
                          </h3>
                          <p className="text-sm text-gray-500">
                            Automated validation and reconciliation of clinical data across multiple sources
                          </p>
                        </div>
                        
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <Shield className="h-4 w-4 mr-2 text-pink-500" />
                            Protocol Compliance
                          </h3>
                          <p className="text-sm text-gray-500">
                            Ensures data collection adheres to protocol requirements and regulatory standards
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="central-monitor" className="p-0 m-0 border-none">
                <div className="space-y-6">
                  {/* Sentinel Guardian Header with Diamond Frame */}
                  <div className="relative rounded-lg bg-gradient-to-r from-slate-700 to-slate-600 p-6 shadow-xl">
                    {/* Grid pattern overlay */}
                    <div className="absolute inset-0 bg-grid-pattern opacity-5 rounded-lg"></div>
                    <div className="absolute inset-0 border border-slate-500/70 rounded-lg"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {/* Diamond frame with scanning effect */}
                          <div className="relative">
                            <div className="absolute inset-0 bg-purple-400 opacity-20 animate-pulse rounded-lg transform rotate-45"></div>
                            <div className="relative h-16 w-16 bg-gradient-to-br from-purple-600 to-indigo-700 rounded-lg flex items-center justify-center shadow-lg border border-purple-400/30 transform rotate-45">
                              <div className="transform -rotate-45">
                                <Shield className="h-8 w-8 text-white" />
                                <div className="absolute h-full w-1 bg-gradient-to-b from-transparent via-purple-300/40 to-transparent left-1/2 -translate-x-1/2 animate-[scan_3s_ease-in-out_infinite]"></div>
                              </div>
                            </div>
                          </div>
                          <div className="ml-4">
                            <h2 className="text-2xl font-bold text-white flex items-center">
                              Sentinel Guardian
                              <Badge className="ml-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white border-none">Central Monitor.AI</Badge>
                            </h2>
                            <p className="text-purple-100/90">Advanced trial monitoring and risk detection system</p>
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleNavigateToAiPage("/central-monitor-ai")}
                          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white border-0"
                        >
                          Launch Full Version
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Central Monitor.AI Features</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <Shield className="h-4 w-4 mr-2 text-purple-500" />
                            Risk-Based Monitoring
                          </h3>
                          <p className="text-sm text-gray-500">
                            Identifies potential risks and issues in real-time across trial sites
                          </p>
                        </div>
                        
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <Server className="h-4 w-4 mr-2 text-purple-500" />
                            Centralized Oversight
                          </h3>
                          <p className="text-sm text-gray-500">
                            Provides comprehensive monitoring of trial performance and data quality
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="csr" className="p-0 m-0 border-none">
                <div className="space-y-6">
                  {/* Report Architect Header with Document-style Frame */}
                  <div className="relative rounded-lg bg-gradient-to-r from-slate-700 to-slate-600 p-6 shadow-xl">
                    {/* Grid pattern overlay */}
                    <div className="absolute inset-0 bg-grid-pattern opacity-5 rounded-lg"></div>
                    <div className="absolute inset-0 border border-slate-500/70 rounded-lg"></div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {/* Document-style frame with blue glow */}
                          <div className="relative">
                            <div className="absolute inset-0 bg-blue-400 opacity-20 animate-pulse rounded-lg"></div>
                            <div className="relative h-16 w-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center shadow-lg border border-blue-400/30">
                              <ClipboardList className="h-8 w-8 text-white" />
                              {/* Document lines effect */}
                              <div className="absolute top-3 left-3 right-3 h-0.5 bg-blue-200 opacity-60"></div>
                              <div className="absolute top-6 left-3 right-3 h-0.5 bg-blue-200 opacity-60"></div>
                              <div className="absolute top-9 left-3 right-3 h-0.5 bg-blue-200 opacity-60"></div>
                            </div>
                          </div>
                          <div className="ml-4">
                            <h2 className="text-2xl font-bold text-white flex items-center">
                              Report Architect
                              <Badge className="ml-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border-none">CSR.AI</Badge>
                            </h2>
                            <p className="text-blue-100/90">Intelligent clinical study reporting assistant</p>
                          </div>
                        </div>
                        <Button 
                          onClick={() => handleNavigateToAiPage("/csr-ai")}
                          className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border-0"
                        >
                          Launch Full Version
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>CSR.AI Features</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <FileText className="h-4 w-4 mr-2 text-blue-500" />
                            Automated Reporting
                          </h3>
                          <p className="text-sm text-gray-500">
                            Generates clinical study reports with consistent formatting and content
                          </p>
                        </div>
                        
                        <div className="border rounded-md p-4">
                          <h3 className="font-medium flex items-center mb-2">
                            <ClipboardList className="h-4 w-4 mr-2 text-blue-500" />
                            Regulatory Compliance
                          </h3>
                          <p className="text-sm text-gray-500">
                            Ensures reports meet regulatory requirements and industry standards
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AppLayout>
  );
}