import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Home,
  FileBarChart,
  Users,
  AlertTriangle,
  CheckSquare,
  BarChart3,
  BellRing,
  ShieldCheck,
  Settings,
  ChevronRight,
  ChevronDown,
  LogOut,
  Badge,
  Sparkles
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";

interface NavItemBase {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  path: string;
  badge?: number;
  children?: NavItemBase[];
}

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState(false);

  // Get unread notification count
  const { data: notificationCountData } = useQuery<{ count: number }>({
    queryKey: ['/api/notifications/count'],
    queryFn: async () => {
      if (!user) return { count: 0 };
      const res = await fetch('/api/notifications/count');
      if (!res.ok) throw new Error('Failed to fetch notifications count');
      return res.json();
    },
    // Only fetch if user is logged in
    enabled: !!user,
    // Refetch every minute and on window focus
    refetchInterval: 60000,
    refetchOnWindowFocus: true,
    staleTime: 30000,
  });

  const handleLogout = () => {
    if (!isLoading) {
      setIsLoading(true);
      
      // Simple logout by redirecting to login page
      fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      })
      .then(() => {
        window.location.href = '/login';
      })
      .catch(error => {
        console.error("Logout failed:", error);
        setIsLoading(false);
      });
    }
  };

  const navItems: NavItemBase[] = [
    {
      name: "AI Agents",
      icon: Sparkles,
      path: "/ai-agents",
      // Special styling will be applied to this item
      badge: 0, // We'll use this to add an accent later
    },
    {
      name: "Dashboard",
      icon: Home,
      path: "/",
    },
    {
      name: "Protocol Digitization.AI",
      icon: FileBarChart,
      path: "/protocol-digitization-ai",
    },
    {
      name: "Study Management",
      icon: Users,
      path: "/study-management",
    },
    {
      name: "Trial Data Management",
      icon: FileBarChart,
      path: "/trial-data-management",
    },
    {
      name: "DM Compliance",
      icon: Badge,
      path: "/data-management",
    },
    {
      name: "Signal Detection",
      icon: AlertTriangle,
      path: "/signal-detection",
    },
    {
      name: "Tasks Management",
      icon: CheckSquare,
      path: "/tasks",
    },
    {
      name: "Profile Management",
      icon: FileBarChart,
      path: "/risk-profiles",
    },
    {
      name: "Reporting and Analytics",
      icon: BarChart3,
      path: "/analytics",
    },
    {
      name: "Notifications",
      icon: BellRing,
      path: "/notifications",
      badge: typeof notificationCountData?.count === 'number' ? notificationCountData.count : 0,
    },
    {
      name: "Admin",
      icon: ShieldCheck,
      path: "/admin",
      children: [
        {
          name: "Settings",
          icon: Settings,
          path: "/settings",
        }
      ]
    },
  ];

  // Get initials for avatar
  const getInitials = (name: string) => {
    if (!name) return "U";
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <aside className="hidden sm:flex flex-col w-64 h-screen bg-white border-r border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h1 className="text-xl font-semibold bg-gradient-to-r from-indigo-600 via-blue-500 to-fuchsia-500 bg-clip-text text-transparent">
          Clinical Cosmos
        </h1>
        <p className="text-xs text-gray-500 mt-1">Redefining Drug Research and Development</p>
      </div>

      <nav className="flex-1 pt-4 pb-4 px-2 overflow-y-auto">
        <div className="space-y-1">
          {navItems.map((item) => (
            <div key={item.path} className="space-y-1">
              {item.children ? (
                <>
                  <button
                    onClick={() => setExpandedItems(prev => ({...prev, [item.path]: !prev[item.path]}))}
                    className={cn(
                      "w-full flex items-center px-3 py-2 text-sm rounded-lg transition-colors",
                      location.startsWith(item.path)
                        ? "bg-primary-50 text-primary font-medium"
                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                    )}
                  >
                    <item.icon
                      className={cn(
                        "mr-3 h-5 w-5",
                        location.startsWith(item.path)
                          ? "text-primary"
                          : "text-gray-500"
                      )}
                    />
                    <span className="flex-1 text-left">{item.name}</span>
                    {expandedItems[item.path] ? 
                      <ChevronDown className="h-4 w-4" /> : 
                      <ChevronRight className="h-4 w-4" />
                    }
                  </button>
                  
                  {expandedItems[item.path] && item.children && (
                    <div className="ml-6 space-y-1 mt-1">
                      {item.children.map((child: NavItemBase) => (
                        <Link
                          key={child.path}
                          href={child.path}
                          className={cn(
                            "flex items-center px-3 py-2 text-sm rounded-lg transition-colors",
                            location === child.path
                              ? "bg-primary-50 text-primary font-medium"
                              : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                          )}
                        >
                          <child.icon
                            className={cn(
                              "mr-3 h-5 w-5",
                              location === child.path
                                ? "text-primary"
                                : "text-gray-500"
                            )}
                          />
                          <span className="flex-1">{child.name}</span>
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  href={item.path}
                  className={cn(
                    "flex items-center px-3 py-2 text-sm rounded-lg transition-colors",
                    item.path === "/ai-agents" 
                      ? "bg-blue-100 text-blue-700 font-medium border border-blue-200" // Special styling for AI Agents
                      : location === item.path
                        ? "bg-primary-50 text-primary font-medium"
                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                  )}
                >
                  <item.icon
                    className={cn(
                      "mr-3 h-5 w-5",
                      item.path === "/ai-agents"
                        ? "text-blue-600" // Special styling for AI Agents icon
                        : location === item.path
                          ? "text-primary"
                          : "text-gray-500"
                    )}
                  />
                  <span className={cn(
                    "flex-1",
                    item.path === "/ai-agents" && "font-semibold" // Make AI Agents text bold
                  )}>
                    {item.name}
                    {item.path === "/ai-agents" && <span className="ml-1 text-xs bg-blue-600 text-white px-1 rounded">New</span>}
                  </span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="ml-auto h-5 min-w-5 rounded-full bg-red-100 text-red-600 text-xs flex items-center justify-center px-1">
                      {item.badge}
                    </span>
                  )}
                </Link>
              )}
            </div>
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-200">
        <div className="flex flex-col space-y-3">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-800 font-medium">
              {user ? getInitials(user.fullName) : 'U'}
            </div>
            <div className="ml-3 flex-1">
              <p className="text-sm font-medium">{user?.fullName || 'User'}</p>
              <p className="text-xs text-gray-500">{user?.role || 'Not authenticated'}</p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            disabled={isLoading}
            className="w-full justify-start text-gray-600 hover:text-red-600 hover:bg-red-50"
          >
            <LogOut className="mr-2 h-4 w-4" />
            <span>Logout</span>
          </Button>
        </div>
      </div>
    </aside>
  );
}